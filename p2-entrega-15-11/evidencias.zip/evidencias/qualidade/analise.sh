#!/usr/bin/env bash
# Análise de qualidade: regras SonarJS (eslint-plugin-sonarjs) + ESLint do Next, cobertura V8 e duplicação (jscpd).
# Uso: analise.sh <rótulo>   (rodar na raiz do projeto)
set -u
TAG="$1"; OUT="/home/claude/p2/qa/$TAG"; mkdir -p "$OUT"
git log -1 --format='%H %s' > "$OUT/commit.txt"
npx eslint --no-eslintrc -c .eslintrc.sonar.json --ext .ts,.tsx src -f json -o "$OUT/eslint.json" >/dev/null 2>"$OUT/eslint.stderr" || true
rm -rf coverage
npx vitest run --coverage --coverage.provider=v8 --coverage.reporter=json-summary --coverage.reporter=text-summary \
  --coverage.include='src/**' --coverage.exclude='**/*.test.ts' > "$OUT/vitest-coverage.log" 2>&1 || true
cp coverage/coverage-summary.json "$OUT/" 2>/dev/null || true
npx --yes jscpd@4 src --min-tokens 70 --reporters json --output "$OUT/jscpd" --silent >/dev/null 2>&1 || true
find src -name '*.ts' -o -name '*.tsx' | grep -v '\.test\.ts$' | xargs cat | grep -cv '^\s*$' > "$OUT/ncloc.txt"
echo "ok $TAG"
