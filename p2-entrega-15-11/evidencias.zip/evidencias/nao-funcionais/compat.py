"""NF-07 Compatibilidade: telas públicas em 3 resoluções (Chrome headless)."""
import json, sys
from playwright.sync_api import sync_playwright
BASE = "http://localhost:3000"
VIEWS = {"desktop-1920x1080": (1920, 1080, False), "tablet-768x1024": (768, 1024, True), "celular-390x844": (390, 844, True)}
PAGES = {"/": ["Entrar", "Criar conta"], "/login": ["Entrar"], "/cadastro": ["Cadastrar"]}
out = []
with sync_playwright() as p:
    b = p.chromium.launch(channel="chrome")
    for vname, (w, h, touch) in VIEWS.items():
        ctx = b.new_context(viewport={"width": w, "height": h}, has_touch=touch, is_mobile=touch and w < 500)
        page = ctx.new_page()
        for path, buttons in PAGES.items():
            page.goto(BASE + path, wait_until="networkidle")
            overflow = page.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
            vis = {}
            for name in buttons:
                loc = page.get_by_role("link", name=name).or_(page.get_by_role("button", name=name)).first
                box = loc.bounding_box()
                vis[name] = bool(loc.is_visible() and box and box["x"] >= 0 and box["x"] + box["width"] <= w)
            shot = f"/home/claude/p2/nf/compat-{vname}{path.replace('/', '-') or '-home'}.png".replace("--", "-")
            page.screenshot(path=shot)
            ok = (not overflow) and all(vis.values())
            out.append({"resolucao": vname, "pagina": path, "rolagem_horizontal": overflow, "botoes_visiveis": vis, "ok": ok, "captura": shot.split('/')[-1]})
        ctx.close()
    b.close()
json.dump(out, open("/home/claude/p2/nf/compat.json", "w"), ensure_ascii=False, indent=1)
for r in out: print(r["resolucao"], r["pagina"], "OK" if r["ok"] else "FALHA", r["botoes_visiveis"], "overflow" if r["rolagem_horizontal"] else "")
